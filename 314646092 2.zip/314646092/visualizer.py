import pygame
import random
import math
import tkinter as tk
from tkinter import simpledialog
from pygame import mixer


def open_pygame_window(use_custom_list, custom_list=None):
    pygame.init()
    main(use_custom_list, custom_list)  # קריאה לפונקציה הראשית  ב-Pygame

def create_choice_window():
    root = tk.Tk()
    root.title("Sorting Algorithms in Pygame 🤞")

    # הגדרת מידות של החלון שיפתח
    window_width = 400
    window_height = 300
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    position_top = int(screen_height / 2 - window_height / 2)
    position_right = int(screen_width / 2 - window_width / 2)
    root.geometry(f'{window_width}x{window_height}+{position_right}+{position_top}')

    label = tk.Label(root, text="🌸 Welcome to my project 🌸 \n Please select an option", font=("Courier New", 16))
    label.pack(pady=10)
    line = tk.Label(root, text="shilat vaizman - 314646092🎗️", font=("Comic Sans MS", 10))
    line.pack(pady=0.5)
    button_random = tk.Button(root, text="Random List", command=lambda: [root.destroy(), open_pygame_window(False)])
    button_random.pack(pady=5)

    button_custom = tk.Button(root, text="Your List", command=lambda: [root.destroy(), get_custom_list()])
    button_custom.pack(pady=10)

    root.mainloop()

def get_custom_list():
    root = tk.Tk()
    root.withdraw()
    user_input = simpledialog.askstring("Input", "Please enter your list:\n **To insert your own list you will have to write , between each number")
    if user_input:
        custom_list = list(map(int, user_input.split(',')))
        open_pygame_window(True, custom_list)
    else:
        open_pygame_window(False)

class DrawInformation:
    YELLOW = 255, 255, 0
    PINK = 255, 0, 127
    BLACK = 0, 0, 0
    WHITE = 255, 255, 255
    GREEN = 0, 255, 0
    RED = 255, 0, 0
    BLUE = 0, 0, 255

    BACKGROUND_COLOR = WHITE
    GRADIENTS = [
        (128, 128, 128),
        (160, 160, 160),
        (192, 192, 192)
    ]

    SIDE_PAD = 100
    TOP_PAD = 150

    def __init__(self, width, height, lst):
        self.width = width
        self.height = height

        self.window = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Sorting Algorithm Visualization")

        self.LARGE_FONT = pygame.font.SysFont('comicsans', 30)
        self.FONT = pygame.font.SysFont('Courier New', 20)
        self.FONT2 = pygame.font.SysFont('Comic Sans MS', 40)
        self.set_list(lst)

    def set_list(self, lst):
        self.lst = lst
        self.min_val = min(lst)
        self.max_val = max(lst)
        self.min_val -= 0.05 * (self.max_val - self.min_val)

        self.block_width = round((self.width - self.SIDE_PAD) / len(lst))
        self.block_height = math.floor((self.height - self.TOP_PAD) / (self.max_val - self.min_val))
        self.start_x = self.SIDE_PAD // 2


def draw(draw_info, algo_name, ascending, FPS, sorting_time=None):
    draw_info.window.fill(draw_info.BACKGROUND_COLOR)

    title = draw_info.FONT2.render(f"{algo_name} - {'Ascending' if ascending else 'Descending'}. {FPS} FPS.", 1, draw_info.PINK)
    draw_info.window.blit(title, (draw_info.width / 2 - title.get_width() / 2, 0.5))

    if sorting_time:
        time_text = draw_info.FONT.render(f"Sorting Time: {sorting_time:.2f} seconds", 1, draw_info.RED)
        draw_info.window.blit(time_text, (draw_info.width / 2 - time_text.get_width() / 2, 30))

    controls = draw_info.FONT.render("R - Reset | SPACE - Start Sorting | A - Ascending", 1, draw_info.BLACK)
    draw_info.window.blit(controls, (draw_info.width / 2 - controls.get_width() / 2, 55))

    controls2 = draw_info.FONT.render("D - Descending |[ - slowly |] -Faster", 1, draw_info.BLACK)
    draw_info.window.blit(controls2, (draw_info.width / 2 - controls.get_width() / 2, 75))

    sorting = draw_info.FONT.render("I - Insertion Sort | B - Bubble Sort | S - Selection Sort", 1, draw_info.BLACK)
    draw_info.window.blit(sorting, (draw_info.width / 2 - sorting.get_width() / 2, 95))

    lines = draw_info.FONT.render("Q - Quick Sort | H - Heap Sort | M - Merge Sort | K - Shaker Sort", 3, draw_info.BLACK)
    draw_info.window.blit(lines, (draw_info.width / 2 - lines.get_width() / 2, 115))

    draw_list(draw_info)
    pygame.display.update()


def draw_list(draw_info, color_positions={}, clear_bg=False, rec_list=[]):
    lst = draw_info.lst

    if clear_bg:
        clear_rect = (draw_info.SIDE_PAD // 2, draw_info.TOP_PAD,
                      draw_info.width - draw_info.SIDE_PAD, draw_info.height - draw_info.TOP_PAD)
        pygame.draw.rect(draw_info.window, draw_info.BACKGROUND_COLOR, clear_rect)

    for i, val in enumerate(lst):
        x = draw_info.start_x + i * draw_info.block_width
        y = draw_info.height - (val - draw_info.min_val) * draw_info.block_height

        color = draw_info.GRADIENTS[i % 3]

        if i in color_positions:
            color = color_positions[i]

        pygame.draw.rect(draw_info.window, color, (x, y, draw_info.block_width, draw_info.height), border_radius=7)

    for i, (a, b) in enumerate(rec_list):
        xa = draw_info.start_x + a * draw_info.block_width
        xb = draw_info.start_x + (b + 1) * draw_info.block_width
        y = draw_info.height - (draw_info.max_val - draw_info.min_val) * draw_info.block_height + 30 * i
        pygame.draw.line(draw_info.window, draw_info.BLUE, (xa, y), (xb, y))

    if clear_bg:
        pygame.display.update()


def draw_blue_sublist(draw_info, lst, start):
    GRADIENTS = [
        (128, 128, 178),
        (160, 160, 210),
        (192, 192, 242)
    ]
    for k, val in enumerate(lst):
        i = k + start
        x = draw_info.start_x + i * draw_info.block_width
        y = draw_info.height - (val - draw_info.min_val) * draw_info.block_height
        color = GRADIENTS[i % 3]
        pygame.draw.rect(draw_info.window, color, (x, y, draw_info.block_width, draw_info.height))
    pygame.display.update()


def generate_starting_list(n, min_val, max_val):
    lst = []

    for _ in range(n):
        val = random.randint(min_val, max_val)
        lst.append(val)

    return lst


def bubble_sort(draw_info, ascending=True):
    lst = draw_info.lst

    for i in range(len(lst) - 1):
        for j in range(len(lst) - 1 - i):
            num1 = lst[j]
            num2 = lst[j + 1]

            if (num1 > num2 and ascending) or (num1 < num2 and not ascending):
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
            draw_list(draw_info, {j: draw_info.GREEN, j + 1: draw_info.RED, len(lst) - i: draw_info.BLUE}, True)
            yield True

    return lst


def shaker_sort(draw_info, ascending=True):
    lst = draw_info.lst
    a = -1
    b = len(lst)
    while a + 1 < b:
        for j in range(a + 1, b - 1):
            num1 = lst[j]
            num2 = lst[j + 1]
            if (num1 > num2 and ascending) or (num1 < num2 and not ascending):
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
            draw_list(draw_info, {j: draw_info.GREEN, j + 1: draw_info.RED, a: draw_info.BLUE, b: draw_info.BLUE}, True)
            yield True
        b -= 1
        for j in range(b - 2, a, -1):
            num1 = lst[j]
            num2 = lst[j + 1]
            if (num1 > num2 and ascending) or (num1 < num2 and not ascending):
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
            draw_list(draw_info, {j: draw_info.GREEN, j + 1: draw_info.RED, a: draw_info.BLUE, b: draw_info.BLUE}, True)
            yield True
        a += 1
    return lst


def selection_sort(draw_info, ascending=True):
    lst = draw_info.lst
    for i in range(len(lst) - 1):
        curmin = i
        curnum = lst[i]
        for j in range(i + 1, len(lst)):
            num = lst[j]
            if (num < curnum and ascending) or (num > curnum and not ascending):
                curmin = j
                curnum = num
            draw_list(draw_info, {j: draw_info.RED, curmin: draw_info.GREEN, i - 1: draw_info.BLUE}, True)
            yield True
        if curmin != i:
            lst[i], lst[curmin] = lst[curmin], lst[i]
        draw_list(draw_info, {i - 1: draw_info.BLUE, i: draw_info.GREEN}, True)
        yield True
    return lst


def insertion_sort(draw_info, ascending=True):
    lst = draw_info.lst

    for i in range(1, len(lst)):
        current = lst[i]

        while True:
            ascending_sort = i > 0 and lst[i - 1] > current and ascending
            descending_sort = i > 0 and lst[i - 1] < current and not ascending

            if not ascending_sort and not descending_sort:
                break

            lst[i] = lst[i - 1]
            i = i - 1
            lst[i] = current
            draw_list(draw_info, {i - 1: draw_info.GREEN, i: draw_info.RED}, True)
            yield True

    return lst


def quick_sort(draw_info, ascending=True):
    lst = draw_info.lst

    rec_list = [(0, len(lst) - 1)]
    while len(rec_list) > 0:
        a, b = rec_list[-1]
        if a < b:
            pivot = a
            cur = b
            while pivot != cur:
                ordersign = (cur - pivot) * (lst[cur] - lst[pivot])
                if (ordersign < 0 and ascending) or (ordersign > 0 and not ascending):
                    lst[cur], lst[pivot] = lst[pivot], lst[cur]
                    cur, pivot = pivot, cur
                else:
                    if cur < pivot:
                        cur += 1
                    else:
                        cur -= 1
                draw_list(draw_info, {pivot: draw_info.GREEN, cur: draw_info.RED}, True, rec_list)
                yield True
            rec_list.append((a, pivot - 1))
        else:
            while len(rec_list) > 0 and rec_list[-1][1] == b:
                rec_list.pop()
            if len(rec_list) > 0:
                rec_list.append((pivot + 1, rec_list[-1][1]))
    return lst


def heap_sort(draw_info, ascending=True):
    lst = draw_info.lst
    for n in range(1, len(lst)):
        cur = n
        while cur > 0:
            parent = (cur - 1) // 2
            num1 = lst[cur]
            num2 = lst[parent]
            if (num1 > num2 and ascending) or (num2 > num1 and not ascending):
                lst[cur], lst[parent] = lst[parent], lst[cur]
                draw_list(draw_info, {cur: draw_info.GREEN, parent: draw_info.RED, n + 1: draw_info.BLUE}, True)
                yield True
            else:
                break
            cur = parent
    for n in range(len(lst) - 1, 0, -1):
        lst[0], lst[n] = lst[n], lst[0]
        draw_list(draw_info, {0: draw_info.RED, n: draw_info.BLUE}, True)
        yield True
        cur = 0
        while 2 * cur + 1 < n:
            two = 2 * cur + 2 < n
            num = lst[cur]
            child1 = lst[2 * cur + 1]
            if two:
                child2 = lst[2 * cur + 2]
            if (child1 > num and ascending) or (child1 < num and not ascending) or (two
                                                                                    and (
                                                                                            child2 > child1 and ascending) or (
                                                                                            child2 < child1 and not ascending)):
                if two and ((child2 > child1 and ascending) or (child2 < child1 and not ascending)):
                    nxt = 2 * cur + 2
                else:
                    nxt = 2 * cur + 1
                lst[cur], lst[nxt] = lst[nxt], lst[cur]
                draw_list(draw_info, {cur: draw_info.RED, nxt: draw_info.GREEN, n: draw_info.BLUE}, True)
                yield True
            else:
                break
            cur = nxt


def merge_sort(draw_info, ascending=True):
    lst = draw_info.lst
    rec_list = []

    def merge_helper(a, b):
        rec_list.append((a, b))
        if a < b:
            mid = (a + b) // 2
            yield from merge_helper(a, mid)
            yield from merge_helper(mid + 1, b)
            newlist = []
            i = a
            j = mid + 1
            while i <= mid and j <= b:
                draw_list(draw_info, {i: draw_info.RED, j: draw_info.GREEN}, True, rec_list)
                draw_blue_sublist(draw_info, newlist, a)
                yield True
                if (lst[i] < lst[j] and ascending) or (lst[i] > lst[j] and not ascending):
                    newlist.append(lst[i])
                    i += 1
                else:
                    newlist.append(lst[j])
                    j += 1
            while i <= mid:
                draw_list(draw_info, {i: draw_info.RED, j: draw_info.GREEN}, True, rec_list)
                draw_blue_sublist(draw_info, newlist, a)
                yield True
                newlist.append(lst[i])
                i += 1
            while j <= b:
                draw_list(draw_info, {i: draw_info.RED, j: draw_info.GREEN}, True, rec_list)
                draw_blue_sublist(draw_info, newlist, a)
                yield True
                newlist.append(lst[j])
                j += 1
            lst[a:b + 1] = newlist
        rec_list.pop()

    yield from merge_helper(0, len(lst) - 1)
    return lst


def main(use_custom_list=False, custom_list=None):
    '''התחול של המוזיקה במשתנים לכל סוג של מיון יש לו
    את המוסיקה שלו לפי המקש שהוגדר לו.'''

    mixer.init()
    mixer.music.load('Play.ht - start.wav')
    space_sound = mixer.Sound('Play.ht - start.wav')
    insertion_sound = mixer.Sound('Insertion Sort 3.wav')
    selection_sound = mixer.Sound('Play.ht - Selection Sort.wav')
    bubble_sound = mixer.Sound('Play.ht - Bubble Sort.wav')
    quick_sound = mixer.Sound('Play.ht - Quick Sort.wav')
    heap_sound = mixer.Sound('Play.ht - Heap Sort.wav')
    merge_sound = mixer.Sound('Play.ht - Merge Sort.wav')
    shaker_sound = mixer.Sound('Play.ht - Shaker Sort.wav')
    slow_sound = mixer.Sound('Play.ht - slow.wav')
    faster_sound = mixer.Sound('Play.ht - Faster.wav')
    end_sound = mixer.Sound('Play.ht - end.wav')
    ascending_sound = mixer.Sound('Play.ht - ascending.wav')
    reset_sound = mixer.Sound('Play.ht - reset.wav')
    descending_sound = mixer.Sound('Play.ht - descending .wav')

    run = True
    clock = pygame.time.Clock()

    n = 50
    min_val = 0
    max_val = 100

    if use_custom_list and custom_list:
        lst = custom_list
    else:
        lst = generate_starting_list(n, min_val, max_val)

    draw_info = DrawInformation(900, 800, lst)

    sorting = False
    ascending = True

    sorting_algorithm = bubble_sort
    sorting_algo_name = "Bubble Sort"
    sorting_algorithm_generator = None

    FPS = 60

    while run:
        clock.tick(FPS)

        if sorting:
            try:
                next(sorting_algorithm_generator)
            except StopIteration:
                sorting = False
                end_sound.play()
        else:
            draw(draw_info, sorting_algo_name, ascending, FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if event.type != pygame.KEYDOWN:
                continue

            if event.key == pygame.K_r:
                reset_sound.play()
                if use_custom_list and custom_list:
                    lst = custom_list
                else:
                    lst = generate_starting_list(n, min_val, max_val)
                draw_info.set_list(lst)
                sorting = False
            elif event.key == pygame.K_LEFTBRACKET:
                slow_sound.play()
                FPS = max(1, FPS - 1)
                draw(draw_info, sorting_algo_name, ascending, FPS)
            elif event.key == pygame.K_RIGHTBRACKET:
                faster_sound.play()
                FPS = min(80, FPS + 1)
                draw(draw_info, sorting_algo_name, ascending, FPS)
            elif event.key == pygame.K_SPACE and sorting == False:
                space_sound.play()
                sorting = True
                sorting_algorithm_generator = sorting_algorithm(draw_info, ascending)
            elif event.key == pygame.K_a and not sorting:
                ascending_sound.play()
                ascending = True
            elif event.key == pygame.K_d and not sorting:
                descending_sound.play()
                ascending = False
            elif event.key == pygame.K_i and not sorting:
                insertion_sound.play()
                sorting_algorithm = insertion_sort
                sorting_algo_name = "Insertion Sort"
            elif event.key == pygame.K_s and not sorting:
                selection_sound.play()
                sorting_algorithm = selection_sort
                sorting_algo_name = "Selection Sort"
            elif event.key == pygame.K_b and not sorting:
                bubble_sound.play()
                sorting_algorithm = bubble_sort
                sorting_algo_name = "Bubble Sort"
            elif event.key == pygame.K_q and not sorting:
                quick_sound.play()
                sorting_algorithm = quick_sort
                sorting_algo_name = "Quick Sort"
            elif event.key == pygame.K_h and not sorting:
                heap_sound.play()
                sorting_algorithm = heap_sort
                sorting_algo_name = "Heap Sort"
            elif event.key == pygame.K_m and not sorting:
                merge_sound.play()
                sorting_algorithm = merge_sort
                sorting_algo_name = "Merge Sort"
            elif event.key == pygame.K_k and not sorting:
                shaker_sound.play()
                sorting_algorithm = shaker_sort
                sorting_algo_name = "Shaker Sort"

    pygame.quit()


if __name__ == "__main__":
    create_choice_window()
