import pygame
pygame.init()

fonts = pygame.font.get_fonts()