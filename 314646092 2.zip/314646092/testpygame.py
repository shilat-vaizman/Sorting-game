import pygame
import random
import math
import tkinter as tk


def open_pygame_window():
    pygame.init()
    main()  # קריאה לפונקציה הראשית שלך ב-Pygame


def create_tkinter_window():
    root = tk.Tk()
    root.title("Start Window")

    # Set window size and center it
    window_width = 400
    window_height = 300
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    position_top = int(screen_height / 2 - window_height / 2)
    position_right = int(screen_width / 2 - window_width / 2)
    root.geometry(f'{window_width}x{window_height}+{position_right}+{position_top}')

    # Add title label with a newline
    label = tk.Label(root, text="Final project\n Graphical Sorting Algorithms in Pygame 🤞 \n 🌸314646092 🌸", font=("Helvetica", 16))
    label.pack(pady=20)

    # Add continue button
    button = tk.Button(root, text="Continue", command=lambda: [root.destroy(), open_pygame_window()])
    button.pack(pady=20)

    root.mainloop()

class DrawInformation:
    BLACK = 0, 0, 0
    WHITE = 255, 255, 255
    GREEN = 0, 255, 0
    RED = 255, 0, 0
    BLUE = 0, 0, 255
    BACKGROUND_COLOR = WHITE

    GRADIENTS = [
        (128, 128, 128),
        (160, 160, 160),
        (192, 192, 192)
    ]

    SIDE_PAD = 100
    TOP_PAD = 150

    def __init__(self, width, height, lst):
        self.width = width
        self.height = height

        self.window = pygame.display.set_mode((width, height))
        pygame.display.set_caption("Sorting Algorithm Visualization")

        # Initialize fonts after pygame.init()
        self.LARGE_FONT = pygame.font.SysFont('comicsans', 30)
        self.FONT = pygame.font.SysFont('Courier New', 20)

        self.set_list(lst)

    def set_list(self, lst):
        self.lst = lst
        self.min_val = min(lst)
        self.max_val = max(lst)
        self.min_val -= 0.05 * (self.max_val - self.min_val)

        self.block_width = round((self.width - self.SIDE_PAD) / len(lst))
        self.block_height = math.floor((self.height - self.TOP_PAD) / (self.max_val - self.min_val))
        self.start_x = self.SIDE_PAD // 2


def draw(draw_info, algo_name, ascending, FPS):
    draw_info.window.fill(draw_info.BACKGROUND_COLOR)

    title = draw_info.LARGE_FONT.render(f"{algo_name} - {'Ascending' if ascending else 'Descending'}. {FPS} FPS.", 1,
                                        draw_info.GREEN)
    draw_info.window.blit(title, (draw_info.width / 2 - title.get_width() / 2, 5))

    controls = draw_info.FONT.render("R - Reset | SPACE - Start Sorting | A - Ascending | D - Descending", 1,draw_info.BLACK)

    draw_info.window.blit(controls, (draw_info.width / 2 - controls.get_width() / 2, 45))

    sorting = draw_info.FONT.render("I - Insertion Sort | B - Bubble Sort | S - Selection Sort", 1, draw_info.BLACK)
    draw_info.window.blit(sorting, (draw_info.width / 2 - sorting.get_width() / 2, 70))

    lines = draw_info.FONT.render("Q - Quick Sort | H - Heap Sort | M - Merge Sort | K - Shaker Sort" , 3, draw_info.BLACK)
    draw_info.window.blit(lines,(draw_info.width / 2 - lines.get_width() / 2, 95))

    draw_list(draw_info)
    pygame.display.update()


def draw_list(draw_info, color_positions={}, clear_bg=False, rec_list=[]):
    lst = draw_info.lst

    if clear_bg:
        clear_rect = (draw_info.SIDE_PAD // 2, draw_info.TOP_PAD,
                      draw_info.width - draw_info.SIDE_PAD, draw_info.height - draw_info.TOP_PAD)
        pygame.draw.rect(draw_info.window, draw_info.BACKGROUND_COLOR, clear_rect)

    for i, val in enumerate(lst):
        x = draw_info.start_x + i * draw_info.block_width
        y = draw_info.height - (val - draw_info.min_val) * draw_info.block_height

        color = draw_info.GRADIENTS[i % 3]

        if i in color_positions:
            color = color_positions[i]

        pygame.draw.rect(draw_info.window, color, (x, y, draw_info.block_width, draw_info.height))

    for i, (a, b) in enumerate(rec_list):
        xa = draw_info.start_x + a * draw_info.block_width
        xb = draw_info.start_x + (b + 1) * draw_info.block_width
        y = draw_info.height - (draw_info.max_val - draw_info.min_val) * draw_info.block_height + 30 * i
        pygame.draw.line(draw_info.window, draw_info.BLUE, (xa, y), (xb, y))

    if clear_bg:
        pygame.display.update()


def draw_blue_sublist(draw_info, lst, start):
    GRADIENTS = [
        (128, 128, 178),
        (160, 160, 210),
        (192, 192, 242)
    ]
    for k, val in enumerate(lst):
        i = k + start
        x = draw_info.start_x + i * draw_info.block_width
        y = draw_info.height - (val - draw_info.min_val) * draw_info.block_height
        color = GRADIENTS[i % 3]
        pygame.draw.rect(draw_info.window, color, (x, y, draw_info.block_width, draw_info.height))
    pygame.display.update()


def generate_starting_list(n, min_val, max_val):
    lst = []

    for _ in range(n):
        val = random.randint(min_val, max_val)
        lst.append(val)

    return lst


def bubble_sort(draw_info, ascending=True):
    lst = draw_info.lst

    for i in range(len(lst) - 1):
        for j in range(len(lst) - 1 - i):
            num1 = lst[j]
            num2 = lst[j + 1]

            if (num1 > num2 and ascending) or (num1 < num2 and not ascending):
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
            draw_list(draw_info, {j: draw_info.GREEN, j + 1: draw_info.RED, len(lst) - i: draw_info.BLUE}, True)
            yield True

    return lst


def shaker_sort(draw_info, ascending=True):
    lst = draw_info.lst
    a = -1
    b = len(lst)
    while a + 1 < b:
        for j in range(a + 1, b - 1):
            num1 = lst[j]
            num2 = lst[j + 1]
            if (num1 > num2 and ascending) or (num1 < num2 and not ascending):
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
            draw_list(draw_info, {j: draw_info.GREEN, j + 1: draw_info.RED, a: draw_info.BLUE, b: draw_info.BLUE}, True)
            yield True
        b -= 1
        for j in range(b - 2, a, -1):
            num1 = lst[j]
            num2 = lst[j + 1]
            if (num1 > num2 and ascending) or (num1 < num2 and not ascending):
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
            draw_list(draw_info, {j: draw_info.GREEN, j + 1: draw_info.RED, a: draw_info.BLUE, b: draw_info.BLUE}, True)
            yield True
        a += 1
    return lst


def selection_sort(draw_info, ascending=True):
    lst = draw_info.lst
    for i in range(len(lst) - 1):
        curmin = i
        curnum = lst[i]
        for j in range(i + 1, len(lst)):
            num = lst[j]
            if (num < curnum and ascending) or (num > curnum and not ascending):
                curmin = j
                curnum = num
            draw_list(draw_info, {j: draw_info.RED, curmin: draw_info.GREEN, i - 1: draw_info.BLUE}, True)
            yield True
        if curmin != i:
            lst[i], lst[curmin] = lst[curmin], lst[i]
        draw_list(draw_info, {i - 1: draw_info.BLUE, i: draw_info.GREEN}, True)
        yield True
    return lst


def insertion_sort(draw_info, ascending=True):
    lst = draw_info.lst

    for i in range(1, len(lst)):
        current = lst[i]

        while True:
            ascending_sort = i > 0 and lst[i - 1] > current and ascending
            descending_sort = i > 0 and lst[i - 1] < current and not ascending

            if not ascending_sort and not descending_sort:
                break

            lst[i] = lst[i - 1]
            i = i - 1
            lst[i] = current
            draw_list(draw_info, {i - 1: draw_info.GREEN, i: draw_info.RED}, True)
            yield True

    return lst


def quick_sort(draw_info, ascending=True):
    lst = draw_info.lst

    rec_list = [(0, len(lst) - 1)]
    while len(rec_list) > 0:
        a, b = rec_list[-1]
        if a < b:
            pivot = a
            cur = b
            while pivot != cur:
                ordersign = (cur - pivot) * (lst[cur] - lst[pivot])
                if (ordersign < 0 and ascending) or (ordersign > 0 and not ascending):
                    lst[cur], lst[pivot] = lst[pivot], lst[cur]
                    cur, pivot = pivot, cur
                else:
                    if cur < pivot:
                        cur += 1
                    else:
                        cur -= 1
                draw_list(draw_info, {pivot: draw_info.GREEN, cur: draw_info.RED}, True, rec_list)
                yield True
            rec_list.append((a, pivot - 1))
        else:
            while len(rec_list) > 0 and rec_list[-1][1] == b:
                rec_list.pop()
            if len(rec_list) > 0:
                rec_list.append((pivot + 1, rec_list[-1][1]))
    return lst


def heap_sort(draw_info, ascending=True):
    lst = draw_info.lst
    for n in range(1, len(lst)):
        cur = n
        while cur > 0:
            parent = (cur - 1) // 2
            num1 = lst[cur]
            num2 = lst[parent]
            if (num1 > num2 and ascending) or (num2 > num1 and not ascending):
                lst[cur], lst[parent] = lst[parent], lst[cur]
                draw_list(draw_info, {cur: draw_info.GREEN, parent: draw_info.RED, n + 1: draw_info.BLUE}, True)
                yield True
            else:
                break
            cur = parent
    for n in range(len(lst) - 1, 0, -1):
        lst[0], lst[n] = lst[n], lst[0]
        draw_list(draw_info, {0: draw_info.RED, n: draw_info.BLUE}, True)
        yield True
        cur = 0
        while 2 * cur + 1 < n:
            two = 2 * cur + 2 < n
            num = lst[cur]
            child1 = lst[2 * cur + 1]
            if two:
                child2 = lst[2 * cur + 2]
            if (child1 > num and ascending) or (child1 < num and not ascending) or (two
                                                                                    and (
                                                                                            child2 > child1 and ascending) or (
                                                                                            child2 < child1 and not ascending)):
                if two and ((child2 > child1 and ascending) or (child2 < child1 and not ascending)):
                    nxt = 2 * cur + 2
                else:
                    nxt = 2 * cur + 1
                lst[cur], lst[nxt] = lst[nxt], lst[cur]
                draw_list(draw_info, {cur: draw_info.RED, nxt: draw_info.GREEN, n: draw_info.BLUE}, True)
                yield True
            else:
                break
            cur = nxt


def merge_sort(draw_info, ascending=True):
    lst = draw_info.lst
    rec_list = []

    def merge_helper(a, b):
        rec_list.append((a, b))
        if a < b:
            mid = (a + b) // 2
            yield from merge_helper(a, mid)
            yield from merge_helper(mid + 1, b)
            newlist = []
            i = a
            j = mid + 1
            while i <= mid and j <= b:
                draw_list(draw_info, {i: draw_info.RED, j: draw_info.GREEN}, True, rec_list)
                draw_blue_sublist(draw_info, newlist, a)
                yield True
                if (lst[i] < lst[j] and ascending) or (lst[i] > lst[j] and not ascending):
                    newlist.append(lst[i])
                    i += 1
                else:
                    newlist.append(lst[j])
                    j += 1
            while i <= mid:
                draw_list(draw_info, {i: draw_info.RED, j: draw_info.GREEN}, True, rec_list)
                draw_blue_sublist(draw_info, newlist, a)
                yield True
                newlist.append(lst[i])
                i += 1
            while j <= b:
                draw_list(draw_info, {i: draw_info.RED, j: draw_info.GREEN}, True, rec_list)
                draw_blue_sublist(draw_info, newlist, a)
                yield True
                newlist.append(lst[j])
                j += 1
            lst[a:b + 1] = newlist
        rec_list.pop()

    yield from merge_helper(0, len(lst) - 1)
    return lst


def main():
    run = True
    clock = pygame.time.Clock()

    n = 50
    min_val = 0
    max_val = 100

    lst = generate_starting_list(n, min_val, max_val)
    draw_info = DrawInformation(800, 600, lst)

    sorting = False
    ascending = True

    sorting_algorithm = bubble_sort
    sorting_algo_name = "Bubble Sort"
    sorting_algorithm_generator = None

    FPS = 60

    while run:
        clock.tick(FPS)

        if sorting:
            try:
                next(sorting_algorithm_generator)
            except StopIteration:
                sorting = False
        else:
            draw(draw_info, sorting_algo_name, ascending, FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if event.type != pygame.KEYDOWN:
                continue

            if event.key == pygame.K_r:
                lst = generate_starting_list(n, min_val, max_val)
                draw_info.set_list(lst)
                sorting = False
            elif event.key == pygame.K_LEFTBRACKET:
                FPS = max(1, FPS - 1)
                draw(draw_info, sorting_algo_name, ascending, FPS)
            elif event.key == pygame.K_RIGHTBRACKET:
                FPS = min(80, FPS + 1)
                draw(draw_info, sorting_algo_name, ascending, FPS)
            elif event.key == pygame.K_SPACE and sorting == False:
                sorting = True
                sorting_algorithm_generator = sorting_algorithm(draw_info, ascending)
            elif event.key == pygame.K_a and not sorting:
                ascending = True
            elif event.key == pygame.K_d and not sorting:
                ascending = False
            elif event.key == pygame.K_i and not sorting:
                sorting_algorithm = insertion_sort
                sorting_algo_name = "Insertion Sort"
            elif event.key == pygame.K_s and not sorting:
                sorting_algorithm = selection_sort
                sorting_algo_name = "Selection Sort"
            elif event.key == pygame.K_b and not sorting:
                sorting_algorithm = bubble_sort
                sorting_algo_name = "Bubble Sort"
            elif event.key == pygame.K_q and not sorting:
                sorting_algorithm = quick_sort
                sorting_algo_name = "Quick Sort"
            elif event.key == pygame.K_h and not sorting:
                sorting_algorithm = heap_sort
                sorting_algo_name = "Heap Sort"
            elif event.key == pygame.K_m and not sorting:
                sorting_algorithm = merge_sort
                sorting_algo_name = "Merge Sort"
            elif event.key == pygame.K_k and not sorting:
                sorting_algorithm = shaker_sort
                sorting_algo_name = "Shaker Sort"

    pygame.quit()


if __name__ == "__main__":
    create_tkinter_window()
